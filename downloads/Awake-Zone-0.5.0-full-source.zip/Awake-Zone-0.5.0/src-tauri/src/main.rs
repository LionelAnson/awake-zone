#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]
fn main() {
    personal_day_lib::run();
}
